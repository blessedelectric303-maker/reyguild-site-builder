import { NextResponse } from "next/server";
import { hasUnsignedDocuments } from "@/lib/signingGate";
import { createClient } from "@/utils/supabase/server";
import { prisma } from "@/lib/prisma";
import { createSessionToken, setSessionCookie, getCurrentUser } from "@/lib/auth";
import { tmRoleFor, normalizeRole } from "@/utils/roles";

// The bridge. You sign in once on ReyGuild; this hands the Time and Material
// app the session it already knows how to read, so there is no second login.
// This MUST be a route handler, not a page: Next.js only allows cookies to be
// written from a route handler or a server action.

export const dynamic = "force-dynamic";

// Only the office tier gets the T and M admin screens. Supervisor, tech and
// apprentice all work from the phone view.
function homeForRole(role: string): string {
  return role === "owner" || role === "admin" ? "/tm/admin" : "/tm/tech";
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  const origin = url.origin;
  // A link can say where it wants to land. Only same-site paths, so this
  // cannot be used to bounce somebody off to another website.
  const wanted = url.searchParams.get("next") || "";
  const safeNext = wanted.startsWith("/") && !wanted.startsWith("//") ? wanted : "";
  const go = (path: string) =>
    NextResponse.redirect(new URL(safeNext || path, origin));
  const problem = (reason: string, detail?: string) => {
    const u = new URL("/tm/no-access", origin);
    u.searchParams.set("reason", reason);
    if (detail) u.searchParams.set("detail", detail);
    return NextResponse.redirect(u);
  };

  // Paperwork first, for the field side too - checked before the session
  // shortcut below, or somebody who signed in yesterday would walk straight
  // past documents added today.
  if (await hasUnsignedDocuments()) return NextResponse.redirect(new URL("/onboarding", origin));

  // Already carrying a valid T and M session? Go straight in.
  try {
    const existing = await getCurrentUser();
    if (existing) return go(homeForRole(existing.role));
  } catch (e) {
    // No usable session yet. Fall through and build one.
  }

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return go("/login");

  const email = (user.email || "").trim().toLowerCase();
  if (!email) return problem("noemail");

  let tmUser = null;
  try {
    tmUser = await prisma.user.findFirst({
      where: { email: { equals: email, mode: "insensitive" }, isActive: true },
    });
  } catch (e) {
    return problem("db");
  }

  // No T and M record yet? Build one from the ReyGuild invite instead of
  // sending somebody to a dead end. This is what makes ONE invite enough -
  // before this, an invited employee got a login that went nowhere because
  // their T and M side had to be typed in separately by hand.
  if (!tmUser) {
    try {
      const { data: mem } = await supabase
        .schema("suite")
        .from("memberships")
        .select("role,company_id")
        .eq("user_id", user.id)
        .limit(1)
        .maybeSingle();
      const suiteRole = normalizeRole((mem as any)?.role);
      const companyId = (mem as any)?.company_id || "";

      // Which company in T and M. This used to be a guess:
      //
      //     const orgs = await prisma.organization.findMany({ take: 2 });
      //     if (orgs.length !== 1) return problem("nouser", email);
      //
      // Right every time while there was one customer, and a dead end the
      // moment there were two. Now the company carries the answer.
      let orgId = "";
      if (companyId) {
        const { data: co } = await supabase
          .schema("suite")
          .from("companies")
          .select("tm_org_id")
          .eq("id", companyId)
          .maybeSingle();
        orgId = ((co as any) || {}).tm_org_id || "";
      }

      // No link yet? Fall back to the old guess, but ONLY while a guess is
      // still safe. Two organisations and no link means we would be putting
      // somebody into another company's jobs and hours, so refuse instead.
      if (!orgId) {
        const orgs = await prisma.organization.findMany({ take: 2, select: { id: true } });
        if (orgs.length !== 1) return problem("nolink", email);
        orgId = orgs[0].id;
      }

      const meta: any = (user as any).user_metadata || {};
      const name =
        (meta.full_name || meta.name || "").trim() ||
        email.split("@")[0];

      tmUser = await prisma.user.create({
        data: {
          id: "usr_" + crypto.randomUUID(),
          orgId,
          email,
          name,
          role: tmRoleFor(suiteRole),
          isActive: true,
          passwordHash: "",
        },
      });
    } catch (e) {
      return problem("nouser", email);
    }
  }

  try {
    const token = await createSessionToken(tmUser.id);
    await setSessionCookie(token);
  } catch (e) {
    return problem("session");
  }

  return go(homeForRole(tmUser.role));
}
